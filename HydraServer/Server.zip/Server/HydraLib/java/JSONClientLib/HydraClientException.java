package JSONClientLib;

public class HydraClientException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public HydraClientException(String message){
		super(message);
	}

}

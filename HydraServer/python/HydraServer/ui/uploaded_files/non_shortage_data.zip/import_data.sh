#!/bin/bash
python ../../../../HydraPlatform/HydraPlugins/CSVplugin/ImportCSV/ImportCSV.py -t network.csv -x -m ../../../templates/Water\ Allocation\ Demo/template/template.xml 
